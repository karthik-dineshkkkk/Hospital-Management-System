<!DOCTYPE html>
<html>
<head>
	<title>Discharge Patient</title>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
		}
		th {
			background-color: #4CAF50;
			color: white;
		}
		tr:nth-child(even) {
			background-color: #f2f2f2;
		}
	</style>
</head>
<body>
	<h1>Discharge Patient</h1>
	<?php
		// Establish connection to database
        include('include/config.php');
		//include('include/checklogin.php');

		// Show stay table
		// Handle form submission
		$query = "SELECT stay.StayID, tblpatient.PatientName, Room.RoomNumber, stay.StayStart, stay.StayEnd
		FROM stay
		INNER JOIN tblpatient ON stay.Patient = tblpatient.ID
		INNER JOIN Room ON stay.Room = Room.RoomNumber
		where stay.StayEnd is NULL";
$result = mysqli_query($con, $query);
if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Stay ID</th><th>Patient Name</th><th>Room Number</th><th>Stay Start</th><th>Stay End</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
	  echo "<tr>";
	  echo "<td>" . $row["StayID"] . "</td>";
	  echo "<td>" . $row["PatientName"] . "</td>";
	  echo "<td>" . $row["RoomNumber"] . "</td>";
	  echo "<td>" . $row["StayStart"] . "</td>";
	  echo "<td>" . $row["StayEnd"] . "</td>";
	  echo "</tr>";
  }
  echo "</table>";
} else {
  echo "No stays found.";
}
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			// Get form data
			$stay_id = $_POST["Doctorspecialization"];




			// Update room availability
			$query = "UPDATE Room
					  INNER JOIN stay ON Room.RoomNumber = stay.Room
					  SET Room.Unavailable = 0
					  WHERE stay.StayID = $stay_id";
			mysqli_query($con, $query);

			// Update stay end date
			$stay_end = date("Y-m-d H:i:s") ;
			$query = "UPDATE stay SET StayEnd = NOW() WHERE StayID = $stay_id";
			mysqli_query($con, $query);

			// Close connection and redirect to front desk page
			
			header("Location:dashboard.php");
			exit();
		}

		// Close connection
		
	?>
	<form role="form" name="book" method="post" >
														


														<div class="form-group">
																													<label for="DoctorSpecialization">
																														Stay ID
																													</label>
																					<select name="Doctorspecialization" class="form-control" onChange="getdoctor(this.value);" required="required">
																														<option value="">Select stayid</option>
														<?php $ret=mysqli_query($con,"select * from Stay where StayEnd is NULL");
														while($row=mysqli_fetch_array($ret))
														{
														?>
																														<option value="<?php echo htmlentities($row['StayID']);?>">
																															<?php echo htmlentities($row['StayID']);?>
																														</option>
																														<?php } ?>
																														
																													</select>
																												</div>
														
																												<button type="submit" name="submit" class="btn btn-o btn-primary">
																													Submit
																												</button>
</body>
</html>
