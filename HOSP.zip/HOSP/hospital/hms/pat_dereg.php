<!DOCTYPE html>
<html>
<head>
	<title>Deregister Patient</title>
    <style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
		}
		th {
			background-color: #4CAF50;
			color: white;
		}
		tr:nth-child(even) {
			background-color: #f2f2f2;
		}
	</style>
</head>
<body>
	<h1>Deregister Patient</h1>
	<?php
		// Establish connection to database
        include('include/config.php');
		//include('include/checklogin.php');

		// Show stay table
		// Handle form submission
        $query = "SELECT * FROM tblpatient";
        $result = mysqli_query($con, $query);
        
        if (mysqli_num_rows($result) > 0) {
          echo "<table>";
          echo "<tr><th>ID</th><th>Patient Name</th><th>Contact Number</th><th>Email</th><th>Gender</th><th>Address</th><th>Age</th></tr>";
          while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>";
              echo "<td>" . $row["ID"] . "</td>";
              echo "<td>" . $row["PatientName"] . "</td>";
              echo "<td>" . $row["PatientContno"] . "</td>";
              echo "<td>" . $row["PatientEmail"] . "</td>";
              echo "<td>" . $row["PatientGender"] . "</td>";
              echo "<td>" . $row["PatientAdd"] . "</td>";
              echo "<td>" . $row["PatientAge"] . "</td>";
              echo "</tr>";
          }
          echo "</table>";
        } else {
          echo "No patients found.";
        }
        
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			// Get form data
			$stay_id = $_POST["Doctorspecialization"];




			// Update room availability

			
			$query = "DELETE FROM tblpatient WHERE ID = $stay_id";
			mysqli_query($con, $query);

			// Close connection and redirect to front desk page
			
			header("Location:dashboard.php");
			exit();
		}

		// Close connection
		
	?>
	<form role="form" name="book" method="post" >
														


														<div class="form-group">
																													<label for="DoctorSpecialization">
																														Patient ID
																													</label>
																					<select name="Doctorspecialization" class="form-control" onChange="getdoctor(this.value);" required="required">
																														<option value="">Select Patient ID</option>
														<?php $ret=mysqli_query($con,"select * from tblpatient");
														while($row=mysqli_fetch_array($ret))
														{
														?>
																														<option value="<?php echo htmlentities($row['ID']);?>">
																															<?php echo htmlentities($row['ID']);?>
																														</option>
																														<?php } ?>
																														
																													</select>
																												</div>
														
																												<button type="submit" name="submit" class="btn btn-o btn-primary">
																													Submit
																												</button>
</body>
</html>
